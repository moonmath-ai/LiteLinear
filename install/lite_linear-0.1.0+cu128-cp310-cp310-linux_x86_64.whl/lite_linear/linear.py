"""LiteLinear: `nn.Linear`-style module whose forward is always LR-CUDA.

On first run, a centralized materialization step decomposes each LiteLinear:
  W ≈ A @ B + Q,  Q -> FP8
and swaps the module to the fused kernel:
  y = (x @ B^T @ A^T) + q_scale * (x @ Q_fp8^T) + bias
"""

from __future__ import annotations

import gc
import hashlib
import os
import sys
import threading
import weakref
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

import torch
from torch import nn
import torch.nn.functional as F

try:
    # Compiled extension (PEP 423 import package: lite_linear._cuda).
    from . import _cuda as _cuda_ext  # type: ignore
except Exception as e:  # pragma: no cover
    _cuda_ext = None
    _CUDA_IMPORT_ERROR: Optional[BaseException] = e
else:
    _CUDA_IMPORT_ERROR = None

try:
    from . import _rocm as _rocm_ext  # type: ignore
except Exception:  # pragma: no cover
    _rocm_ext = None


_FACTOR_FIELDS = ("A", "B", "Q_fp8", "Q_scale_inv", "bias")
_FP8_REMAINDER_DTYPE = (
    torch.float8_e4m3fnuz
    if bool(getattr(torch.version, "hip", None)) and hasattr(torch, "float8_e4m3fnuz")
    else torch.float8_e4m3fn
)


def _fp8_max_for_dtype(dtype: torch.dtype) -> float:
    if dtype == torch.float8_e4m3fnuz:
        return 240.0
    return 448.0


def _use_rocm_native(x: torch.Tensor) -> bool:
    if _rocm_ext is None:
        return False
    if not x.is_cuda:
        return False
    if not bool(getattr(torch.version, "hip", None)):
        return False
    mode = os.environ.get("LITELINEAR_ENABLE_ROCM_EXT", "1").strip().lower()
    if mode in {"0", "off", "false", "no"}:
        return False
    return True


def _flatten_2d(x: torch.Tensor) -> torch.Tensor:
    return x.reshape(-1, x.shape[-1])


def _current_program_path() -> Optional[Path]:
    try:
        import __main__
    except Exception:
        __main__ = None
    main_path = getattr(__main__, "__file__", None) if __main__ is not None else None
    if main_path:
        return Path(main_path)
    argv0 = sys.argv[0] if sys.argv else ""
    if argv0 and argv0 not in ("-c", "-m"):
        return Path(argv0)
    return None


def _cache_root() -> Path:
    root = os.environ.get("LITELINEAR_CACHE") or os.environ.get("HF_HOME")
    if root:
        return Path(root).expanduser()
    prog = _current_program_path()
    base = prog.resolve().parent if prog is not None else Path.cwd()
    return base / ".cache" / "litelinear"


def _cache_paths(*, fingerprint: str, rank: int) -> Dict[str, Path]:
    cache_dir = _cache_root() / "lr_data"
    cache_dir.mkdir(parents=True, exist_ok=True)
    stem = f"lite_linear_{fingerprint}_r{rank}"
    suffix = ".safetensors"
    return {
        "calib": cache_dir / f"{stem}_calib{suffix}",
        "nocalib": cache_dir / f"{stem}_nocalib{suffix}",
    }


def _meta_with_r(meta: Dict[str, str]) -> bool:
    raw = meta.get("with_r")
    if raw is None:
        # Back-compat for older caches.
        raw = meta.get("calib")
    return str(raw).lower() in ("1", "true", "yes", "y")


def _with_r_tag_from_modules(mods: Sequence["LiteLinear"]) -> str:
    # LiteLinear factors are derived from direct SVD, so default to nocalib.
    # If a future path sets an explicit attribute, respect it.
    for m in mods:
        for attr in ("with_r"):
            if getattr(m, attr, False):
                return "calib"
    return "nocalib"


def _cache_path_for_tag(tag: str, *, fingerprint: str, rank: int) -> Path:
    paths = _cache_paths(fingerprint=fingerprint, rank=rank)
    return paths.get(tag, paths["nocalib"])


def _find_matching_cache(
    *,
    fingerprint: str,
    rank: int,
) -> Optional[Tuple[Path, Dict[str, Dict[str, torch.Tensor]], Dict[str, str]]]:
    matches: list[Tuple[str, Path, Dict[str, Dict[str, torch.Tensor]], Dict[str, str]]] = []
    for tag, path in _cache_paths(fingerprint=fingerprint, rank=rank).items():
        if not path.exists():
            continue
        factors, meta = _load_factors(path)
        if meta.get("fingerprint") == fingerprint and meta.get("rank") == str(rank):
            meta_with_r = _meta_with_r(meta)
            if tag == "calib" and not meta_with_r:
                print(
                    f"[LiteLinear] Warning: cache filename suggests calibrated but metadata says with_r=0: {path}",
                    flush=True,
                )
            if tag == "nocalib" and meta_with_r:
                print(
                    f"[LiteLinear] Warning: cache filename suggests not calibrated but metadata says with_r=1: {path}",
                    flush=True,
                )
            matches.append((tag, path, factors, meta))
    if not matches:
        return None
    # Prefer calibrated caches when both exist.
    matches.sort(
        key=lambda m: (
            not _meta_with_r(m[3]),
            m[0] != "calib",
        )
    )
    _, path, factors, meta = matches[0]
    return path, factors, meta
    return None


def _split_factor_key(key: str) -> Tuple[str, str]:
    for field in _FACTOR_FIELDS:
        suf = f".{field}"
        if key.endswith(suf):
            return key[: -len(suf)], field
    raise ValueError(f"Unrecognized factor key: {key}")


def _load_factors(path: Path) -> Tuple[Dict[str, Dict[str, torch.Tensor]], Dict[str, str]]:
    from safetensors import safe_open

    out: Dict[str, Dict[str, torch.Tensor]] = {}
    meta: Dict[str, str] = {}
    with safe_open(str(path), framework="pt", device="cpu") as f:
        meta = f.metadata() or {}
        for k in f.keys():
            name, field = _split_factor_key(k)
            out.setdefault(name, {})[field] = f.get_tensor(k)
    return out, meta


def _save_factors(path: Path, factors: Dict[str, Dict[str, torch.Tensor]], *, meta: Dict[str, str]) -> None:
    from safetensors.torch import save_file

    path.parent.mkdir(parents=True, exist_ok=True)
    flat: Dict[str, torch.Tensor] = {}
    for name, entry in factors.items():
        for field, t in entry.items():
            if t is None:
                continue
            tc = t.detach().cpu().contiguous()
            if tc.dtype == torch.float8_e4m3fnuz:
                # safetensors torch backend does not support fnuz dtype yet.
                tc = tc.to(dtype=torch.float8_e4m3fn)
            flat[f"{name}.{field}"] = tc
    save_file(flat, str(path), metadata={k: str(v) for k, v in meta.items()})


@torch.no_grad()
def _svd_factors(W: torch.Tensor, rank: int) -> Tuple[torch.Tensor, torch.Tensor]:
    # W: [N,K] -> A:[N,r], B:[r,K]
    W32 = W.to(dtype=torch.float32)
    n, k = W32.shape
    r = min(int(rank), n, k)
    U, S, Vh = torch.linalg.svd(W32, full_matrices=False)
    U_r = U[:, :r]
    S_r = S[:r]
    Vh_r = Vh[:r, :]
    A = U_r * S_r.unsqueeze(0)
    B = Vh_r
    return A, B


@torch.no_grad()
def _quantize_fp8_per_tensor(t: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    # FP8 E4M3 per-tensor scale.
    amax = t.abs().max()
    fp8_max = _fp8_max_for_dtype(_FP8_REMAINDER_DTYPE)
    scale = (fp8_max / amax.clamp(min=1e-12)).to(dtype=torch.float32)
    q_fp8 = (t * scale).to(dtype=_FP8_REMAINDER_DTYPE)
    return q_fp8, scale.reciprocal().to(dtype=torch.float32)


@torch.no_grad()
def _requantize_to_target_fp8(q_fp8: torch.Tensor, q_scale_inv: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    # Migrate precomputed factors across FP8 variants safely.
    q32 = q_fp8.to(dtype=torch.float32) * q_scale_inv.to(dtype=torch.float32)
    amax = q32.abs().max()
    fp8_max = _fp8_max_for_dtype(_FP8_REMAINDER_DTYPE)
    scale = (fp8_max / amax.clamp(min=1e-12)).to(dtype=torch.float32)
    q_new = (q32 * scale).to(dtype=_FP8_REMAINDER_DTYPE)
    return q_new.contiguous(), scale.reciprocal().to(dtype=torch.float32).contiguous()


class LiteLinear(nn.Linear):
    DEFAULT_RANK = 64
    _INSTANCES: "weakref.WeakSet[LiteLinear]" = weakref.WeakSet()
    _MAT_LOCK = threading.Lock()
    _MAT_DONE: set[str] = set()

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        device=None,
        dtype=None,
        *,
        rank: Optional[int] = None,
    ) -> None:
        super().__init__(
            in_features=in_features,
            out_features=out_features,
            bias=bias,
            device=device,
            dtype=dtype,
        )
        self.rank = int(self.DEFAULT_RANK if rank is None else rank)
        self.cast_threads: int = 256

        # Materialized representation (buffers). When materialized:
        # - self.weight becomes FP8 remainder (buffer)
        # - self.bias becomes BF16 bias (buffer or None)
        # IMPORTANT: keep these **non-persistent** so loading original checkpoints (which won't have them)
        # does not fail with missing keys.
        # Also keep them off the meta device: checkpoints are loaded via a meta-init + assign=True path,
        # and meta buffers would later break `.to(cuda)` with "Cannot copy out of meta tensor".
        buf_dev = torch.device("cpu")
        self.register_buffer("A", torch.empty((0, 0), dtype=torch.bfloat16, device=buf_dev), persistent=False)
        self.register_buffer("B", torch.empty((0, 0), dtype=torch.bfloat16, device=buf_dev), persistent=False)
        self.register_buffer("Q_deq_bf16", torch.empty((0, 0), dtype=torch.bfloat16, device=buf_dev), persistent=False)
        self.register_buffer("Q_scale_inv", torch.tensor(0.0, dtype=torch.float32, device=buf_dev), persistent=False)
        self._q_scale_float: float | None = None
        self._materialized: bool = False
        # Stable-ish key assigned during load_state_dict (prefix passed by PyTorch).
        self._lite_key: str | None = None

        # Register instance for centralized materialization.
        LiteLinear._INSTANCES.add(self)

    def _load_from_state_dict(  # noqa: D401
        self,
        state_dict,
        prefix,
        local_metadata,
        strict,
        missing_keys,
        unexpected_keys,
        error_msgs,
    ):
        # PyTorch passes module prefix like "transformer_blocks.0.attn1.to_q."
        # Strip trailing "." so it matches `named_modules()` keys.
        if isinstance(prefix, str):
            key = prefix[:-1] if prefix.endswith(".") else prefix
            self._lite_key = key
        return super()._load_from_state_dict(
            state_dict,
            prefix,
            local_metadata,
            strict,
            missing_keys,
            unexpected_keys,
            error_msgs,
        )

    def train(self, mode: bool = True):  # noqa: D401
        out = super().train(mode)
        if not mode:
            # Centralized one-time decomposition+cache/load for all LiteLinear instances.
            self._maybe_materialize_all()
        return out

    @staticmethod
    @torch.no_grad()
    def replace_activation_proj_(act_fn: nn.Module) -> bool:
        """
        Replace `act_fn.proj` (if it's an `nn.Linear`) with `LiteLinear`.

        This is used for FFN w1, since diffusers activation modules (GEGLU/GELU/ApproximateGELU)
        hardcode `self.proj = nn.Linear(...)` internally.

        Returns True if a replacement was performed.
        """
        proj = getattr(act_fn, "proj", None)
        if not isinstance(proj, nn.Linear) or isinstance(proj, LiteLinear):
            return False

        new_proj = LiteLinear(
            proj.in_features,
            proj.out_features,
            bias=(proj.bias is not None),
            device=proj.weight.device,
            dtype=proj.weight.dtype,
        )

        # Preserve initialization when not on meta (meta weights cannot be copied).
        if not getattr(proj.weight, "is_meta", False):
            new_proj.weight.copy_(proj.weight)
            if proj.bias is not None and new_proj.bias is not None:
                new_proj.bias.copy_(proj.bias)

        act_fn.proj = new_proj
        return True

    def _apply(self, fn, recurse=True):  # noqa: D401
        super()._apply(fn, recurse=recurse)
        if self._materialized:
            # Keep kernel-required dtypes stable under `.to(dtype=...)`.
            if isinstance(self.weight, torch.Tensor):
                self.weight = self.weight.to(dtype=_FP8_REMAINDER_DTYPE).contiguous()
            if self.bias is not None and isinstance(self.bias, torch.Tensor):
                self.bias = self.bias.to(dtype=torch.bfloat16).contiguous()
            if isinstance(self.A, torch.Tensor) and self.A.numel() > 0:
                self.A = self.A.to(dtype=torch.bfloat16).contiguous()
            if isinstance(self.B, torch.Tensor) and self.B.numel() > 0:
                self.B = self.B.to(dtype=torch.bfloat16).contiguous()
            if isinstance(self.Q_deq_bf16, torch.Tensor) and self.Q_deq_bf16.numel() > 0:
                self.Q_deq_bf16 = self.Q_deq_bf16.to(dtype=torch.bfloat16).contiguous()
            if isinstance(self.Q_scale_inv, torch.Tensor):
                self.Q_scale_inv = self.Q_scale_inv.to(dtype=torch.float32).contiguous()
                if self.Q_scale_inv.numel() == 1 and self.Q_scale_inv.is_cuda:
                    self._q_scale_float = float(self.Q_scale_inv.item())
        return self

    @torch.no_grad()
    def materialize_from_weight(self, *, rank: Optional[int] = None) -> Dict[str, torch.Tensor]:
        if not self.weight.is_cuda:
            raise RuntimeError("LiteLinear requires CUDA weights for materialization.")

        r = self.rank if rank is None else int(rank)
        A32, B32 = _svd_factors(self.weight, r)
        Q32 = self.weight.to(dtype=torch.float32) - (A32 @ B32)
        Q_fp8, q_scale_inv = _quantize_fp8_per_tensor(Q32)

        A = A32.to(dtype=torch.bfloat16).contiguous()
        B = B32.to(dtype=torch.bfloat16).contiguous()
        bias = self.bias.to(dtype=torch.bfloat16).contiguous() if self.bias is not None else None

        self._install_factors(A=A, B=B, Q_fp8=Q_fp8.contiguous(), Q_scale_inv=q_scale_inv.contiguous(), bias=bias)
        out: Dict[str, torch.Tensor] = {"A": A, "B": B, "Q_fp8": self.weight, "Q_scale_inv": self.Q_scale_inv}
        if self.bias is not None:
            out["bias"] = self.bias
        return out

    @torch.no_grad()
    def _install_factors(
        self,
        *,
        A: torch.Tensor,
        B: torch.Tensor,
        Q_fp8: torch.Tensor,
        Q_scale_inv: torch.Tensor,
        bias: Optional[torch.Tensor],
    ) -> None:
        q_scale = Q_scale_inv.to(dtype=torch.float32).contiguous()
        q_tensor = Q_fp8.contiguous()
        if q_tensor.dtype != _FP8_REMAINDER_DTYPE:
            q_tensor, q_scale = _requantize_to_target_fp8(q_tensor, q_scale)

        # Replace Parameters with buffers to free full-precision weights.
        if "weight" in self._parameters:
            del self._parameters["weight"]
        self.register_buffer("weight", q_tensor.to(dtype=_FP8_REMAINDER_DTYPE).contiguous(), persistent=True)

        if "bias" in self._parameters:
            del self._parameters["bias"]
        if bias is None:
            self.bias = None
        else:
            self.register_buffer("bias", bias.to(dtype=torch.bfloat16).contiguous(), persistent=True)

        self.A = A.to(dtype=torch.bfloat16).contiguous()
        self.B = B.to(dtype=torch.bfloat16).contiguous()
        self.Q_scale_inv = q_scale
        q_deq_check = (self.weight.to(dtype=torch.float32) * self.Q_scale_inv).to(dtype=torch.bfloat16)
        if not torch.isfinite(q_deq_check).all():
            raise RuntimeError("LiteLinear factors contain non-finite values after FP8 conversion")
        # Keep fallback dequantized remainder unmaterialized by default to save memory.
        self.Q_deq_bf16 = torch.empty((0, 0), dtype=torch.bfloat16, device=self.weight.device)
        self._q_scale_float = float(self.Q_scale_inv.item())
        self._materialized = True

    @torch.no_grad()
    def _ensure_q_deq_bf16(self) -> torch.Tensor:
        if (
            isinstance(self.Q_deq_bf16, torch.Tensor)
            and self.Q_deq_bf16.numel() > 0
            and self.Q_deq_bf16.device == self.weight.device
            and self.Q_deq_bf16.dtype == torch.bfloat16
            and self.Q_deq_bf16.shape == self.weight.shape
        ):
            return self.Q_deq_bf16
        q = (self.weight.to(dtype=torch.float32) * self.Q_scale_inv).to(dtype=torch.bfloat16).contiguous()
        if not torch.isfinite(q).all():
            raise RuntimeError("LiteLinear fallback remainder contains non-finite values")
        self.Q_deq_bf16 = q
        return self.Q_deq_bf16

    @torch.no_grad()
    def _forward_rocm_native(self, x2d: torch.Tensor) -> torch.Tensor:
        assert _rocm_ext is not None
        q_scale = self._q_scale_float
        if q_scale is None:
            q_scale = float(self.Q_scale_inv.item())
            self._q_scale_float = q_scale
        return _rocm_ext.fused_forward(
            x2d,
            self.weight,
            self.A,
            self.B,
            self.bias if self.bias is not None else None,
            float(q_scale),
            int(self.cast_threads),
        )

    @torch.no_grad()
    def _forward_torch_fallback(self, x2d: torch.Tensor) -> torch.Tensor:
        lr = F.linear(F.linear(x2d, self.B), self.A)
        rem = F.linear(x2d, self._ensure_q_deq_bf16())
        y2d = lr + rem
        if self.bias is not None:
            y2d = y2d + self.bias.to(dtype=lr.dtype)
        return y2d

    def forward(self, input: torch.Tensor) -> torch.Tensor:  # noqa: D401
        if not self._materialized:
            # Allow lazy materialization on first use (still centralized).
            self._maybe_materialize_all()
            if not self._materialized:
                raise RuntimeError("LiteLinear materialization did not run (unexpected).")

        x2d = _flatten_2d(input)
        if x2d.shape[-1] != self.in_features:
            raise ValueError(f"Expected x last dim {self.in_features}, got {x2d.shape[-1]}")
        if not x2d.is_cuda:
            raise RuntimeError("LiteLinear requires CUDA inputs.")
        if x2d.dtype != torch.bfloat16:
            x2d = x2d.to(dtype=torch.bfloat16)
        if not x2d.is_contiguous():
            x2d = x2d.contiguous()

        if _cuda_ext is not None:
            q_scale = self._q_scale_float
            if q_scale is None:
                q_scale = float(self.Q_scale_inv.item())
                self._q_scale_float = q_scale
            y2d = _cuda_ext.fused_forward(
                x2d,
                self.weight,
                self.A,
                self.B,
                self.bias if self.bias is not None else None,
                float(q_scale),
            )
        elif _use_rocm_native(x2d):
            y2d = self._forward_rocm_native(x2d)
        else:
            y2d = self._forward_torch_fallback(x2d)
        return y2d.view(*input.shape[:-1], self.out_features)

    @classmethod
    @torch.no_grad()
    def _maybe_materialize_all(cls) -> Path:
        """
        Centralized one-time decomposition+cache/load for all LiteLinear instances in-process.

        Triggered automatically by `model.eval()` (via `LiteLinear.train(False)`).
        """
        with cls._MAT_LOCK:
            # Collect unmaterialized instances that have been loaded (have a key).
            mods = [m for m in list(cls._INSTANCES) if isinstance(m, cls) and not m._materialized]
            if not mods:
                # Nothing to do.
                return _cache_path_for_tag("nocalib", fingerprint="none", rank=cls.DEFAULT_RANK)

            # Ensure all have keys (assigned during load_state_dict).
            missing = [m for m in mods if not m._lite_key]
            if missing:
                raise RuntimeError(
                    "LiteLinear instances missing state_dict prefix keys. "
                    "Make sure you load the model weights before calling eval()."
                )

            # Ensure CUDA (we only support CUDA path).
            for m in mods:
                if not m.weight.is_cuda:
                    raise RuntimeError(
                        "LiteLinear materialization requires CUDA weights. Move the model to CUDA before eval()."
                    )

            # Determine rank (must be consistent).
            rank = int(mods[0].rank)
            if any(int(m.rank) != rank for m in mods):
                raise RuntimeError("Mixed LiteLinear ranks detected; expected a single global rank.")

            # Stable ordering by key.
            mods.sort(key=lambda m: str(m._lite_key))

            # Compute fingerprint (architecture + a small weight sample).
            h = hashlib.sha1()
            h.update(f"rank={rank}\n".encode())
            h.update(f"factor_version=2\n".encode())
            h.update(f"fp8_dtype={str(_FP8_REMAINDER_DTYPE)}\n".encode())
            h.update(f"fp8_max={_fp8_max_for_dtype(_FP8_REMAINDER_DTYPE)}\n".encode())
            for m in mods:
                h.update(
                    f"{m._lite_key}|{m.out_features}|{m.in_features}|{1 if m.bias is not None else 0}\n".encode()
                )

            # Sample a few modules to disambiguate checkpoints with same shapes.
            idxs = {0, len(mods) // 2, len(mods) - 1}
            for i in sorted(idxs):
                m = mods[i]
                w = m.weight.detach().reshape(-1)[:64].to(dtype=torch.float32).cpu()
                h.update(w.numpy().tobytes())
                if m.bias is not None:
                    b = m.bias.detach().reshape(-1)[:64].to(dtype=torch.float32).cpu()
                    h.update(b.numpy().tobytes())

            fingerprint = h.hexdigest()[:16]
            if fingerprint in cls._MAT_DONE:
                cached = _find_matching_cache(fingerprint=fingerprint, rank=rank)
                if cached is not None:
                    return cached[0]
                return _cache_path_for_tag(
                    _with_r_tag_from_modules(mods),
                    fingerprint=fingerprint,
                    rank=rank,
                )

            cached = _find_matching_cache(fingerprint=fingerprint, rank=rank)
            if cached is not None:
                path, factors, _ = cached
                print(
                    f"[LiteLinear] Loading cached factors: {path} (rank={rank}, modules={len(mods)})",
                    flush=True,
                )
                count = 0
                for m in mods:
                    key = str(m._lite_key)
                    entry = factors.get(key)
                    if entry is None:
                        raise KeyError(f"Missing LiteLinear factors for key: {key}")
                    dev = m.weight.device
                    bias_t = entry.get("bias")
                    m._install_factors(
                        A=entry["A"].to(device=dev),
                        B=entry["B"].to(device=dev),
                        Q_fp8=entry["Q_fp8"].to(device=dev),
                        Q_scale_inv=entry["Q_scale_inv"].to(device=dev),
                        bias=bias_t.to(device=dev) if bias_t is not None else None,
                    )
                    count += 1
                    if count % 5 == 0:
                        print(f"  ... loaded {count} layers", flush=True)
                        gc.collect()
                        torch.cuda.empty_cache()
                cls._MAT_DONE.add(fingerprint)
                return path

            tag = _with_r_tag_from_modules(mods)
            path = _cache_path_for_tag(tag, fingerprint=fingerprint, rank=rank)

            print(
                f"[LiteLinear] Materializing factors: {path} (rank={rank}, modules={len(mods)})",
                flush=True,
            )
            built: Dict[str, Dict[str, torch.Tensor]] = {}
            count = 0
            for m in mods:
                key = str(m._lite_key)
                built[key] = m.materialize_from_weight(rank=rank)
                count += 1
                if count % 5 == 0:
                    print(f"  ... decomposed {count} layers", flush=True)
                    gc.collect()
                    torch.cuda.empty_cache()

            _save_factors(
                path,
                built,
                meta={
                    "format": "ltx_lite_linear_factors",
                    "version": "2",
                    "rank": str(rank),
                    "fingerprint": fingerprint,
                    "n_modules": str(len(mods)),
                    "with_r": "1" if tag == "calib" else "0",
                    "fp8_dtype": str(_FP8_REMAINDER_DTYPE),
                    "fp8_max": str(_fp8_max_for_dtype(_FP8_REMAINDER_DTYPE)),
                },
            )
            print(f"[LiteLinear] Done: {path}", flush=True)
            cls._MAT_DONE.add(fingerprint)
            return path
