from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .checkpoint_patch_core import (
    build_patched_checkpoint,
    default_cache_root,
    generate_patch_config_from_checkpoint,
    patched_checkpoint_path,
    resolve_or_build_patched_checkpoint,
)
from .patched_checkpoint import get_safe_open_for_patch_build


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build LiteLinear patched safetensors checkpoint offline.",
    )
    parser.add_argument(
        "--source",
        required=True,
        help="Source .safetensors file to patch.",
    )
    parser.add_argument(
        "--rank",
        type=int,
        default=64,
        help="LiteLinear decomposition rank (default: 64).",
    )
    parser.add_argument(
        "--tag",
        default=os.environ.get("LITELINEAR_PATCH_TAG", "nocalib"),
        choices=("calib", "nocalib"),
        help="Patch tag used in output filename.",
    )
    parser.add_argument(
        "--cache-root",
        default=None,
        help=(
            "Cache root to place generated patched files "
            "(defaults to LITELINEAR_CACHE, else HF_HOME/litelinear_cache, else current_program_path/litelinear_cache)."
        ),
    )
    parser.add_argument(
        "--config",
        default=os.environ.get("LITELINEAR_PATCH_CONFIG", None),
        help="Path to LiteLinear patch config JSON (layer_names/include/exclude filters).",
    )
    parser.add_argument(
        "--ensure-config",
        action="store_true",
        help="If --config path does not exist, auto-generate it from source checkpoint.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Optional explicit output path. If omitted, canonical cache path is used.",
    )
    parser.add_argument(
        "--copy-original",
        action="store_true",
        help="Also keep a copy/hardlink of the original checkpoint in patch cache directory.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Rebuild destination even if it already exists.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    src_input = Path(args.source).expanduser()
    if src_input.suffix != ".safetensors":
        raise FileNotFoundError(f"Expected .safetensors source file path, got: {src_input}")
    src = src_input.absolute()
    if not src.is_file():
        raise FileNotFoundError(f"Expected existing .safetensors source file, got: {src_input}")

    tag = "calib" if str(args.tag).strip().lower() == "calib" else "nocalib"
    rank = int(args.rank)
    cache_root = Path(args.cache_root).expanduser().resolve() if args.cache_root else default_cache_root()
    safe_open_fn = get_safe_open_for_patch_build()
    config_path = Path(args.config).expanduser().resolve() if args.config else None
    print(
        f"[LiteLinear Offline] Start: source={src_input} rank={rank} tag={tag} "
        f"cache_root={cache_root} device=cuda",
        flush=True,
    )
    if config_path is not None:
        print(f"[LiteLinear Offline] Config: {config_path}", flush=True)

    if config_path is not None and args.ensure_config and not config_path.exists():
        config_path.parent.mkdir(parents=True, exist_ok=True)
        generated = generate_patch_config_from_checkpoint(src, safe_open_fn=safe_open_fn)
        with config_path.open("w", encoding="utf-8") as f:
            json.dump(generated, f, indent=2, sort_keys=True)
            f.write("\n")
        print(f"[LiteLinear Offline] Generated config: {config_path}")

    if args.output:
        dst = Path(args.output).expanduser().resolve()
        if dst.exists() and not args.force:
            print(f"[LiteLinear Offline] Output exists, reusing: {dst}", flush=True)
            print(dst)
            return 0
        dst.parent.mkdir(parents=True, exist_ok=True)
        built = build_patched_checkpoint(
            src,
            dst,
            rank=rank,
            tag=tag,
            safe_open_fn=safe_open_fn,
            patch_config_path=config_path,
        )
        print(dst if built else src)
        return 0

    cached_dst = patched_checkpoint_path(src, rank=rank, tag=tag, cache_root=cache_root)
    if cached_dst.exists() and not args.force:
        print(f"[LiteLinear Offline] Using cached patched checkpoint: {cached_dst}", flush=True)
        print(cached_dst)
        return 0

    resolved = resolve_or_build_patched_checkpoint(
        src,
        rank=rank,
        tag=tag,
        cache_root=cache_root,
        copy_original=bool(args.copy_original),
        force_rebuild=bool(args.force),
        safe_open_fn=safe_open_fn,
        log_prefix="[LiteLinear Offline]",
        patch_config_path=config_path,
    )
    print(resolved)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
