from __future__ import annotations

import os
from pathlib import Path
from typing import Callable

from .checkpoint_patch_core import default_cache_root, resolve_or_build_patched_checkpoint

_BOOL_TRUE = ("1", "true", "yes", "y", "on")
_SAFE_OPEN_ORIG = None
_INSTALLED = False


def _env_true(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).strip().lower() in _BOOL_TRUE


def _online_patch_enabled() -> bool:
    # New explicit toggle for current online path.
    return _env_true("LITEFFN_ONLINE_PATCH", "1")


def _patch_runtime_enabled() -> bool:
    return _env_true("LITEFFN_PATCHED_CHECKPOINT", "1")


def _patch_copy_original_enabled() -> bool:
    return _env_true("LITEFFN_PATCH_COPY_ORIGINAL", "1")


def _patch_force_rebuild_enabled() -> bool:
    return _env_true("LITEFFN_PATCH_FORCE_REBUILD", "0")


def _patched_tag() -> str:
    tag = os.environ.get("LITEFFN_PATCH_TAG", "nocalib").strip().lower()
    return "calib" if tag == "calib" else "nocalib"


def _patch_cache_root() -> Path:
    return default_cache_root()


def _patch_config_path() -> Path | None:
    raw = os.environ.get("LITEFFN_PATCH_CONFIG", "").strip()
    if not raw:
        return None
    return Path(raw).expanduser()


def get_safe_open_for_patch_build() -> Callable:
    import safetensors

    return _SAFE_OPEN_ORIG if _SAFE_OPEN_ORIG is not None else safetensors.safe_open


def install_safe_open_patch(rank_provider: Callable[[], int]) -> bool:
    global _SAFE_OPEN_ORIG, _INSTALLED
    if _INSTALLED:
        return True
    if not _online_patch_enabled():
        return False
    try:
        import safetensors
    except Exception:
        return False

    if _SAFE_OPEN_ORIG is None:
        _SAFE_OPEN_ORIG = safetensors.safe_open

    def _patched_safe_open(filename, framework="pt", device="cpu"):  # noqa: ANN001
        try:
            resolved = Path(filename)
            if _patch_runtime_enabled():
                resolved = resolve_or_build_patched_checkpoint(
                    resolved,
                    rank=int(rank_provider()),
                    tag=_patched_tag(),
                    cache_root=_patch_cache_root(),
                    copy_original=_patch_copy_original_enabled(),
                    force_rebuild=_patch_force_rebuild_enabled(),
                    safe_open_fn=_SAFE_OPEN_ORIG,
                    log_prefix="[LiteFFN]",
                    patch_config_path=_patch_config_path(),
                )
            if str(resolved) != str(filename):
                print(f"[LiteFFN] Redirected safe_open -> {resolved}", flush=True)
            return _SAFE_OPEN_ORIG(str(resolved), framework=framework, device=device)
        except Exception:
            return _SAFE_OPEN_ORIG(str(filename), framework=framework, device=device)

    safetensors.safe_open = _patched_safe_open
    _INSTALLED = True
    return True
