from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Callable

import torch

_LOCK = threading.Lock()
_INFLIGHT: dict[str, threading.Lock] = {}
_PATCHABLE_COUNT_MEMO: dict[str, int] = {}


def current_program_path() -> Path | None:
    try:
        import __main__
    except Exception:
        __main__ = None
    main_path = getattr(__main__, "__file__", None) if __main__ is not None else None
    if main_path:
        return Path(main_path)
    argv0 = sys.argv[0] if sys.argv else ""
    if argv0 and argv0 not in ("-c", "-m"):
        return Path(argv0)
    return None


def default_cache_root() -> Path:
    root = os.environ.get("LITEFFN_CACHE")
    if root:
        return Path(root).expanduser()
    hf_home = os.environ.get("HF_HOME")
    if hf_home:
        return Path(hf_home).expanduser() / "liteffn_cache"
    prog = current_program_path()
    base = prog.resolve().parent if prog is not None else Path.cwd()
    return base / "liteffn_cache"


@torch.no_grad()
def svd_factors(W: torch.Tensor, rank: int) -> tuple[torch.Tensor, torch.Tensor]:
    W32 = W.to(dtype=torch.float32)
    n, k = W32.shape
    r = min(int(rank), n, k)
    U, S, Vh = torch.linalg.svd(W32, full_matrices=False)
    U_r = U[:, :r]
    S_r = S[:r]
    Vh_r = Vh[:r, :]
    A = U_r * S_r.unsqueeze(0)
    B = Vh_r
    return A, B


@torch.no_grad()
def quantize_fp8_per_tensor(t: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    amax = t.abs().max()
    fp8_max = 448.0
    scale = (fp8_max / amax.clamp(min=1e-12)).to(dtype=torch.float32)
    q_fp8 = (t * scale).to(dtype=torch.float8_e4m3fn)
    return q_fp8, scale.reciprocal().to(dtype=torch.float32)


def _config_list(cfg: dict, key: str) -> list[str]:
    raw = cfg.get(key, [])
    if raw is None:
        return []
    if isinstance(raw, str):
        raw = [raw]
    if not isinstance(raw, list):
        raise ValueError(f"Patch config field '{key}' must be a list of strings.")
    return [str(x).strip() for x in raw if str(x).strip()]


def load_patch_config(config_path: Path | None) -> dict:
    if config_path is None:
        return {}
    if not config_path.is_file():
        raise FileNotFoundError(f"LiteFFN patch config not found: {config_path}")
    with config_path.open("r", encoding="utf-8") as f:
        cfg = json.load(f)
    if not isinstance(cfg, dict):
        raise ValueError("LiteFFN patch config must be a JSON object.")
    return cfg


def _pair_selected_by_config(w1_prefix: str, w2_prefix: str, cfg: dict | None) -> bool:
    return module_selected_by_config(w1_prefix, cfg) or module_selected_by_config(w2_prefix, cfg)


def module_selected_by_config(module_prefix: str, cfg: dict | None) -> bool:
    if not cfg:
        return True

    module_prefix = str(module_prefix or "")
    if not module_prefix:
        return True

    exact_prefixes = set(_config_list(cfg, "exact_prefixes"))
    if exact_prefixes and module_prefix not in exact_prefixes:
        return False

    layer_names = set(_config_list(cfg, "layer_names"))
    if layer_names:
        segments = set(module_prefix.split("."))
        if segments.isdisjoint(layer_names):
            return False

    include_contains = _config_list(cfg, "include_contains")
    if include_contains and not any(s in module_prefix for s in include_contains):
        return False

    include_regex = _config_list(cfg, "include_regex")
    if include_regex:
        if not any(re.search(pat, module_prefix) for pat in include_regex):
            return False

    exclude_contains = _config_list(cfg, "exclude_contains")
    if any(s in module_prefix for s in exclude_contains):
        return False

    exclude_regex = _config_list(cfg, "exclude_regex")
    if any(re.search(pat, module_prefix) for pat in exclude_regex):
        return False

    return True


def candidate_lite_prefix_pairs(keys: set[str], *, patch_config: dict | None = None) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    for weight_key in sorted(keys):
        if not weight_key.endswith(".net.0.proj.weight"):
            continue
        w1_prefix = weight_key[: -len(".weight")]
        w2_prefix = w1_prefix.replace(".net.0.proj", ".net.2")
        if f"{w2_prefix}.weight" in keys and _pair_selected_by_config(w1_prefix, w2_prefix, patch_config):
            out.append((w1_prefix, w2_prefix))
    return out


def _patch_config_digest(cfg: dict) -> str:
    payload = json.dumps(cfg or {}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha1(payload.encode()).hexdigest()[:16]


def _patchable_count_cache_path(src_path: Path, *, config_digest: str) -> Path:
    src_abs = src_path.resolve()
    model_id = hashlib.sha1(str(src_abs).encode()).hexdigest()[:16]
    out_dir = default_cache_root() / "patched_models" / model_id
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir / f"{src_abs.stem}.patchable_pairs_{config_digest}.json"


def _load_cached_patchable_count(
    cache_path: Path, *, src_abs: Path, src_size: int, src_mtime_ns: int, config_digest: str
) -> int | None:
    if not cache_path.is_file():
        return None
    try:
        with cache_path.open("r", encoding="utf-8") as f:
            cached = json.load(f)
    except Exception:
        return None
    if not isinstance(cached, dict):
        return None
    if str(cached.get("source_path", "")) != str(src_abs):
        return None
    if int(cached.get("source_size", -1)) != int(src_size):
        return None
    if int(cached.get("source_mtime_ns", -1)) != int(src_mtime_ns):
        return None
    if str(cached.get("config_digest", "")) != config_digest:
        return None
    try:
        return int(cached["patchable_pairs"])
    except Exception:
        return None


def _store_cached_patchable_count(
    cache_path: Path, *, src_abs: Path, src_size: int, src_mtime_ns: int, config_digest: str, count: int
) -> None:
    payload = {
        "source_path": str(src_abs),
        "source_size": int(src_size),
        "source_mtime_ns": int(src_mtime_ns),
        "config_digest": config_digest,
        "patchable_pairs": int(count),
    }
    tmp = cache_path.with_suffix(cache_path.suffix + ".tmp")
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, sort_keys=True)
        f.write("\n")
    os.replace(tmp, cache_path)


def count_patchable_pairs_for_checkpoint(
    src_path: Path,
    *,
    safe_open_fn: Callable,
    patch_config_path: Path | None = None,
) -> int:
    src_abs = src_path.resolve()
    stat = src_abs.stat()
    patch_config = load_patch_config(patch_config_path)
    config_digest = _patch_config_digest(patch_config)
    memo_key = (
        f"{src_abs}|{int(stat.st_size)}|{int(stat.st_mtime_ns)}|{config_digest}"
    )
    with _LOCK:
        if memo_key in _PATCHABLE_COUNT_MEMO:
            return _PATCHABLE_COUNT_MEMO[memo_key]

    cache_path = _patchable_count_cache_path(src_abs, config_digest=config_digest)
    cached_count = _load_cached_patchable_count(
        cache_path,
        src_abs=src_abs,
        src_size=int(stat.st_size),
        src_mtime_ns=int(stat.st_mtime_ns),
        config_digest=config_digest,
    )
    if cached_count is not None:
        with _LOCK:
            _PATCHABLE_COUNT_MEMO[memo_key] = cached_count
        return cached_count

    with safe_open_fn(str(src_path), framework="pt", device="cpu") as src:
        keys = set(src.keys())
    pairs = candidate_lite_prefix_pairs(keys, patch_config=patch_config)
    count = len(pairs)
    with _LOCK:
        _PATCHABLE_COUNT_MEMO[memo_key] = count
    try:
        _store_cached_patchable_count(
            cache_path,
            src_abs=src_abs,
            src_size=int(stat.st_size),
            src_mtime_ns=int(stat.st_mtime_ns),
            config_digest=config_digest,
            count=count,
        )
    except Exception:
        pass
    return count


def safe_cached_copy(src: Path, dst: Path) -> None:
    if dst.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(str(src), str(dst))
        return
    except OSError:
        pass
    shutil.copy2(src, dst)


def patched_checkpoint_path(src_path: Path, *, rank: int, tag: str, cache_root: Path) -> Path:
    src_abs = src_path.resolve()
    model_id = hashlib.sha1(str(src_abs).encode()).hexdigest()[:16]
    out_dir = cache_root / "patched_models" / model_id
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir / f"{src_path.stem}.liteffn_patched.{tag}_{rank}{src_path.suffix}"


def resolve_cached_patched_checkpoint_path(
    src_path: Path,
    *,
    rank: int,
    tag: str,
    cache_root: Path | None = None,
) -> Path | None:
    src = Path(src_path).expanduser()
    root = cache_root.expanduser() if cache_root is not None else default_cache_root()
    candidate = patched_checkpoint_path(src, rank=int(rank), tag=str(tag), cache_root=root)
    return candidate if candidate.is_file() else None


def resolve_strict_checkpoint_path(
    src_path: Path,
    *,
    rank: int,
    tag: str,
    safe_open_fn: Callable,
    patch_config_path: Path | None = None,
    name: str = "checkpoint_path",
    cache_root: Path | None = None,
    log_prefix: str = "[LiteFFN]",
) -> Path:
    src = Path(src_path).expanduser()
    if not src.is_file():
        raise FileNotFoundError(f"LiteFFN strict mode ({name}): expected existing checkpoint file, got: {src}")
    if ".liteffn_patched." in src.name:
        return src

    cached = resolve_cached_patched_checkpoint_path(
        src,
        rank=int(rank),
        tag=str(tag),
        cache_root=cache_root,
    )
    if cached is not None:
        print(f"{log_prefix} Strict mode: resolved cached patched {name}: {cached}", flush=True)
        return cached

    patchable_pairs = count_patchable_pairs_for_checkpoint(
        src,
        safe_open_fn=safe_open_fn,
        patch_config_path=patch_config_path,
    )
    if patchable_pairs == 0:
        print(
            f"{log_prefix} Strict mode: {name} has no patchable FFN pairs under current filter; "
            f"using original file: {src}",
            flush=True,
        )
        return src

    raise RuntimeError(
        "LiteFFN strict mode is enabled (online patch disabled), "
        f"but {name} is not a patched checkpoint path and has {patchable_pairs} patchable FFN pairs: {src}"
    )


def generate_patch_config_from_checkpoint(src_path: Path, *, safe_open_fn: Callable) -> dict:
    with safe_open_fn(str(src_path), framework="pt", device="cpu") as src:
        keys = set(src.keys())
    pairs = candidate_lite_prefix_pairs(keys, patch_config=None)
    layer_names: set[str] = set()
    for w1_prefix, _ in pairs:
        if w1_prefix.endswith(".net.0.proj"):
            base = w1_prefix[: -len(".net.0.proj")]
        else:
            base = w1_prefix
        if "." in base:
            layer_names.add(base.split(".")[-1])
    return {
        "version": 1,
        "layer_names": sorted(layer_names),
        "include_contains": [],
        "exclude_contains": [],
        "include_regex": [],
        "exclude_regex": [],
        "exact_prefixes": [],
    }


@torch.no_grad()
def build_patched_checkpoint(
    src_path: Path,
    dst_path: Path,
    *,
    rank: int,
    tag: str,
    safe_open_fn: Callable,
    patch_config_path: Path | None = None,
    log_prefix: str = "[LiteFFN]",
) -> bool:
    from safetensors.torch import save_file

    t0 = time.perf_counter()
    if not torch.cuda.is_available():
        raise RuntimeError("Offline patch decomposition requires CUDA")
    comp_dev = torch.device("cuda")
    print(
        f"{log_prefix} Build start: src={src_path} dst={dst_path} rank={rank} tag={tag} device={comp_dev}",
        flush=True,
    )
    patch_config = load_patch_config(patch_config_path)
    if patch_config_path is not None:
        print(f"{log_prefix} Using patch config: {patch_config_path}", flush=True)
    with safe_open_fn(str(src_path), framework="pt", device="cpu") as src:
        keys = list(src.keys())
        key_set = set(keys)
        pairs = candidate_lite_prefix_pairs(key_set, patch_config=patch_config)
        print(f"{log_prefix} Scan complete: tensors={len(keys)} matched_ffn_pairs={len(pairs)}", flush=True)
        if not pairs:
            print(f"{log_prefix} No matching FFN pairs found; leaving file unchanged.", flush=True)
            return False

        removed_keys: set[str] = set()
        added: dict[str, torch.Tensor] = {}
        modules_total = len(pairs) * 2
        done = 0
        step = max(1, modules_total // 10)
        decomp_t0 = time.perf_counter()
        for w1_prefix, w2_prefix in pairs:
            for module_prefix in (w1_prefix, w2_prefix):
                w_key = f"{module_prefix}.weight"
                b_key = f"{module_prefix}.bias"
                if w_key not in key_set:
                    continue

                W = src.get_tensor(w_key).to(device=comp_dev, dtype=torch.float32)
                A32, B32 = svd_factors(W, rank)
                Q32 = W - (A32 @ B32)
                Q_fp8, q_scale_inv = quantize_fp8_per_tensor(Q32)
                added[f"{module_prefix}.A"] = A32.to(dtype=torch.bfloat16).contiguous().to(device="cpu")
                added[f"{module_prefix}.B"] = B32.to(dtype=torch.bfloat16).contiguous().to(device="cpu")
                added[f"{module_prefix}.Q_fp8"] = Q_fp8.contiguous().to(device="cpu")
                added[f"{module_prefix}.Q_scale_inv"] = q_scale_inv.to(dtype=torch.float32).contiguous().to(device="cpu")
                if b_key in key_set:
                    added[f"{module_prefix}.bias"] = src.get_tensor(b_key).to(dtype=torch.bfloat16).contiguous().cpu()
                    removed_keys.add(b_key)
                removed_keys.add(w_key)
                done += 1
                if comp_dev.type == "cuda":
                    torch.cuda.synchronize(comp_dev)
                del W, A32, B32, Q32, Q_fp8, q_scale_inv
                if done % step == 0 or done == modules_total:
                    elapsed = time.perf_counter() - decomp_t0
                    rate = done / max(elapsed, 1e-6)
                    print(
                        f"{log_prefix} Decompose progress: {done}/{modules_total} modules "
                        f"(elapsed={elapsed:.1f}s, rate={rate:.2f} mod/s)",
                        flush=True,
                    )

        out_tensors: dict[str, torch.Tensor] = {}
        for key in keys:
            if key in removed_keys:
                continue
            out_tensors[key] = src.get_tensor(key).contiguous().cpu()
        out_tensors.update(added)
        print(
            f"{log_prefix} Assemble complete: kept={len(out_tensors)-len(added)} "
            f"added={len(added)} removed={len(removed_keys)}",
            flush=True,
        )

        meta = dict(src.metadata() or {})
        meta.update(
            {
                "liteffn_patched": "1",
                "liteffn_rank": str(rank),
                "liteffn_tag": str(tag),
                "liteffn_source": str(src_path),
                "liteffn_version": "1",
                "liteffn_patched_pairs": str(len(pairs)),
                "liteffn_patch_config": str(patch_config_path) if patch_config_path is not None else "",
            }
        )

    tmp_path = dst_path.with_suffix(dst_path.suffix + ".tmp")
    print(f"{log_prefix} Writing patched checkpoint: tmp={tmp_path}", flush=True)
    save_file(out_tensors, str(tmp_path), metadata={k: str(v) for k, v in meta.items()})
    os.replace(tmp_path, dst_path)
    total = time.perf_counter() - t0
    print(f"{log_prefix} Write complete: {dst_path} (total={total:.1f}s)", flush=True)
    return True


def resolve_or_build_patched_checkpoint(
    src_path: Path,
    *,
    rank: int,
    tag: str,
    cache_root: Path,
    copy_original: bool,
    force_rebuild: bool,
    safe_open_fn: Callable,
    log_prefix: str = "[LiteFFN]",
    patch_config_path: Path | None = None,
) -> Path:
    if ".liteffn_patched." in src_path.name:
        return src_path
    if src_path.suffix != ".safetensors" or not src_path.is_file():
        return src_path

    dst_path = patched_checkpoint_path(src_path, rank=rank, tag=tag, cache_root=cache_root)
    source_copy_path = dst_path.parent / src_path.name
    lock_path = dst_path.with_suffix(dst_path.suffix + ".lock")
    key = str(dst_path)

    with _LOCK:
        lock = _INFLIGHT.setdefault(key, threading.Lock())

    with lock:
        if dst_path.exists() and not force_rebuild:
            print(f"{log_prefix} Using cached patched checkpoint: {dst_path}", flush=True)
            return dst_path

        if copy_original:
            safe_cached_copy(src_path, source_copy_path)

        lock_fd = None
        while True:
            try:
                lock_fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(lock_fd, str(os.getpid()).encode())
                break
            except FileExistsError:
                if dst_path.exists() and not force_rebuild:
                    print(f"{log_prefix} Using cached patched checkpoint: {dst_path}", flush=True)
                    return dst_path
                print(f"{log_prefix} Waiting for build lock: {lock_path}", flush=True)
                time.sleep(0.2)

        try:
            if dst_path.exists() and not force_rebuild:
                print(f"{log_prefix} Using cached patched checkpoint: {dst_path}", flush=True)
                return dst_path
            if build_patched_checkpoint(
                src_path,
                dst_path,
                rank=rank,
                tag=tag,
                safe_open_fn=safe_open_fn,
                patch_config_path=patch_config_path,
                log_prefix=log_prefix,
            ):
                print(f"{log_prefix} Built patched checkpoint: {dst_path}", flush=True)
                return dst_path
            return src_path
        finally:
            if lock_fd is not None:
                os.close(lock_fd)
            try:
                os.unlink(lock_path)
            except FileNotFoundError:
                pass
