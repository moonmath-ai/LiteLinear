"""Pure-math primitives for low-rank + FP8 weight decomposition.

The one function users reach for is :func:`decompose_weight`: dense ``W`` in,
the LiteLinear factor quad ``(A, B, Q_fp8, Q_scale_inv)`` out.
"""

import warnings

import torch

# A/B storage dtypes accepted by decompose_weight; fp8 too lossy, fp64 unused.
_ALLOWED_AB_DTYPES = (torch.bfloat16, torch.float16, torch.float32)


def _validate_input(name: str, t: torch.Tensor) -> None:
    """Validate W or R at decompose_weight's input boundary (dtype / non-empty / finite)."""
    if not t.dtype.is_floating_point:
        raise TypeError(f"{name} must be floating-point; got {t.dtype}")
    if t.numel() == 0:
        raise ValueError(f"{name} cannot be empty; got shape {tuple(t.shape)}")
    # SVD raises on NaN but silently propagates inf, producing nan/inf factors with no error downstream.
    if not t.isfinite().all():
        raise ValueError(
            f"{name} contains non-finite values (NaN / inf); decomposition "
            f"would silently produce garbage factors. Inspect your checkpoint."
        )


@torch.no_grad()
def _r_sqrt_and_inv_sqrt(
    r: torch.Tensor, *, eps: float = 1e-6
) -> tuple[torch.Tensor, torch.Tensor]:
    r"""Compute :math:`R^{1/2}` and :math:`R^{-1/2}` via symmetric eigendecomposition.

    Args:
        r: symmetric positive semi-definite matrix.
        eps: regularizer added to the diagonal before the eigendecomposition,
            and a clamp floor on the eigenvalues. Stabilizes rank-deficient R.

    Shape:
        - Input ``r``: :math:`(d, d)`.
        - Output ``sqrt``: :math:`(d, d)`, equal to :math:`R^{1/2}`.
        - Output ``inv_sqrt``: :math:`(d, d)`, equal to :math:`R^{-1/2}`.
    """
    if r.ndim != 2 or r.shape[0] != r.shape[1]:
        raise ValueError("r must be square [d, d]")
    r = 0.5 * (r + r.transpose(0, 1))
    d = r.shape[0]
    eye = torch.eye(d, device=r.device, dtype=r.dtype)
    r = r + eps * eye

    evals, evecs = torch.linalg.eigh(r)
    evals = evals.clamp_min(eps)
    sqrt = evecs @ torch.diag(evals.sqrt()) @ evecs.transpose(0, 1)
    inv_sqrt = evecs @ torch.diag(evals.rsqrt()) @ evecs.transpose(0, 1)
    return sqrt, inv_sqrt


@torch.no_grad()
def _low_rank_factors(
    W: torch.Tensor, *, rank: int, R: torch.Tensor | None = None
) -> tuple[torch.Tensor, torch.Tensor]:
    r"""Low-rank approximation :math:`W \approx A B`, optionally R-aware.

    With ``R`` the SVD operates on :math:`W R^{1/2}` and :math:`B` is right-
    multiplied by :math:`R^{-1/2}`, so the low-rank piece minimizes
    :math:`\|(W - AB) R^{1/2}\|_F` instead of :math:`\|W - AB\|_F` —
    aligning the truncation with the empirical input second-moment
    :math:`R`.

    Args:
        W: dense weight matrix, fp32.
        rank: truncation rank. Must satisfy
            :math:`\text{rank} \le \min(d_{out}, d_{in})`; higher ranks raise.
        R: optional :math:`R = X^\top X / N`, fp32 on ``W.device``.

    Shape:
        - Input ``W``: :math:`(d_{out}, d_{in})`.
        - Input ``R`` (when provided): :math:`(d_{in}, d_{in})`, symmetric PSD.
        - Output ``A``: :math:`(d_{out}, \text{rank})`.
        - Output ``B``: :math:`(\text{rank}, d_{in})`.
    """
    # Strict dtype guards: decompose_weight casts at its boundary, so internals stay no-cast.
    if W.dtype != torch.float32:
        raise TypeError(
            f"W must be fp32 (boundary cast lives in decompose_weight); got {W.dtype}"
        )
    if R is not None and R.dtype != torch.float32:
        raise TypeError(
            f"R must be fp32 (boundary cast lives in decompose_weight); got {R.dtype}"
        )
    if W.ndim != 2:
        raise ValueError("W must be 2D [d_out, d_in]")
    if rank <= 0:
        raise ValueError("rank must be positive")
    rank = int(rank)  # defensive against np.int64 / 0-d Tensor scalar
    d_out, d_in = W.shape
    if rank > min(d_out, d_in):
        raise ValueError(
            f"rank {rank} exceeds min(d_out, d_in)={min(d_out, d_in)} "
            f"(W is {d_out}x{d_in}); clamp at the call site if you need a "
            f"uniform rank across mixed-dim layers."
        )

    if R is not None:
        # Tropp-style change of basis: SVD W·R^(1/2) and undo on B.
        r_sqrt, r_sqrt_inv = _r_sqrt_and_inv_sqrt(R)
        W_eff = W @ r_sqrt
    else:
        r_sqrt_inv = None
        W_eff = W

    U, S, Vh = torch.linalg.svd(W_eff, full_matrices=False)
    A = U[:, :rank] * S[:rank].unsqueeze(0)
    B = Vh[:rank, :]
    if r_sqrt_inv is not None:
        B = B @ r_sqrt_inv
    return A, B


@torch.no_grad()
def _quantize_to_fp8(
    tensor: torch.Tensor,
    dtype: torch.dtype = torch.float8_e4m3fn,
    static_scale: torch.Tensor | None = None,
    saturate: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    r"""Quantize ``tensor`` to FP8 with a per-tensor scale.

    Args:
        tensor: input tensor of any shape.
        dtype: FP8 dtype, either ``torch.float8_e4m3fn`` (NVIDIA) or
            ``torch.float8_e4m3fnuz`` (AMD ROCm).
        static_scale: skip the dynamic amax computation and use this scalar
            fp32 *forward* (quant) scale instead. Useful for calibration or
            when several tensors must share a scale. Note the asymmetric
            convention: ``static_scale`` is the forward scale (large value)
            because that's what calibration callers naturally compute,
            while the returned ``scale_inv`` is its reciprocal (matches
            the on-disk and runtime dequant convention).
        saturate: a ``static_scale`` above the amax scale pushes the largest
            entries past the FP8 range; that raises by default, or clips
            them to ``±fp8_max`` (a saturating cast) when ``saturate=True``.
            Only for callers that clip *intentionally* (above-amax
            calibration scales). No effect on the dynamic amax path, which
            cannot overflow.

    Shape:
        - Input ``tensor``: :math:`(*)`, any shape.
        - Input ``static_scale`` (when provided): :math:`(1,)` or :math:`()`
          (1-element fp32, either layout).
        - Output ``q_fp8``: same shape as ``tensor``, ``dtype``.
        - Output ``scale_inv``: :math:`(1,)`, fp32.

    Raises:
        ValueError: on a non-FP8 ``dtype``, or when ``static_scale``
            overflows any entry and ``saturate`` is False.
    """
    if not (dtype.is_floating_point and dtype.itemsize == 1):
        raise ValueError(f"Expected an FP8 dtype, got {dtype}")

    finfo = torch.finfo(dtype)
    if static_scale is not None:
        # Normalize device + dtype: kernel consumes scale_inv as an fp32
        # scalar on the input tensor's device.
        scale = static_scale.to(device=tensor.device, dtype=torch.float32)
    else:
        amax = tensor.abs().max()
        scale = (finfo.max / amax.clamp(min=1e-12)).to(dtype=torch.float32)

    # The bare fp8 cast has no inf to overflow into: anything past finfo.max
    # becomes NaN.
    if saturate:
        q_fp8 = (tensor * scale).clamp(finfo.min, finfo.max).to(dtype)
    else:
        q_fp8 = (tensor * scale).to(dtype)
        # Checked on the output, not on amax * scale: a pre-check would
        # false-trip on the fp32 rounding sliver right at finfo.max.
        bad = q_fp8.float().isnan() & ~tensor.isnan()
        if bad.any():
            raise ValueError(
                f"scale={scale.item():.4g} overflows "
                f"{int(bad.sum())} element(s) past {dtype} max "
                f"{finfo.max}; pass saturate=True to clip intentionally."
            )

    # Shape (1,) so it can load into LiteLinear.Q_scale_inv (FSDP-friendly).
    return q_fp8, scale.reciprocal().reshape(1)


@torch.no_grad()
def decompose_weight(
    W: torch.Tensor,
    *,
    rank: int,
    R: torch.Tensor | None = None,
    ab_dtype: torch.dtype = torch.bfloat16,
    q_dtype: torch.dtype = torch.float8_e4m3fn,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    r"""Decompose ``W`` into the LiteLinear factor quad.

    :math:`W \approx A B + Q_{fp8} \cdot s` where :math:`s` is the scalar
    dequant scale ``scale_inv``.

    ``Q_fp8`` encodes the residual of the returned, ``ab_dtype``-rounded
    factors, so ``A.float() @ B.float() + Q_fp8.float() * scale_inv``
    reconstructs ``W`` up to FP8 rounding alone.

    Lossy fp64+ downcasts of ``W`` or ``R`` to the fp32 math precision emit
    a UserWarning.

    Args:
        W: dense weight matrix; any floating-point dtype.
        rank: truncation rank for the low-rank piece. Must satisfy
            ``rank <= min(d_out, d_in)``; higher ranks raise ValueError.
        R: empirical input second-moment :math:`X^\top X / N`, optional.
            When supplied the decomposition is data-aware; when ``None`` it
            falls back to plain truncated SVD.
        ab_dtype: storage dtype for ``A`` and ``B``. Default
            ``torch.bfloat16`` (the kernel's required dtype); ``torch.float16``
            and ``torch.float32`` are also allowed.
        q_dtype: FP8 variant for ``Q_fp8``. Default
            ``torch.float8_e4m3fn`` (NVIDIA); pass ``torch.float8_e4m3fnuz``
            for AMD ROCm.

    Shape:
        - Input ``W``: :math:`(d_{out}, d_{in})`.
        - Input ``R`` (when provided): :math:`(d_{in}, d_{in})`, symmetric PSD.
        - Output ``A``: :math:`(d_{out}, \text{rank})`, ``ab_dtype``.
        - Output ``B``: :math:`(\text{rank}, d_{in})`, ``ab_dtype``.
        - Output ``Q_fp8``: :math:`(d_{out}, d_{in})`, ``q_dtype``.
        - Output ``scale_inv``: :math:`(1,)`, fp32.
    """
    if ab_dtype not in _ALLOWED_AB_DTYPES:
        raise ValueError(
            f"ab_dtype must be one of {_ALLOWED_AB_DTYPES}; got {ab_dtype}."
        )
    _validate_input("W", W)
    if W.dtype.itemsize > 4:  # fp64 (and any future >fp32 float)
        warnings.warn(
            f"decompose_weight: W dtype {W.dtype} downcast to fp32 (lossy)",
            UserWarning,
            stacklevel=2,
        )
    # Upcast for math: SVD precision needs more mantissa than bf16/fp16, and
    # the residual Q = W - A@B suffers catastrophic cancellation otherwise.
    W = W.to(dtype=torch.float32)
    if R is not None:
        _validate_input("R", R)
        if R.dtype.itemsize > 4:
            warnings.warn(
                f"decompose_weight: R dtype {R.dtype} downcast to fp32 (lossy)",
                UserWarning,
                stacklevel=2,
            )
        # fp32 for eigh+sqrt accuracy; device follows W.
        R = R.to(device=W.device, dtype=torch.float32)
    A, B = _low_rank_factors(W, rank=rank, R=R)
    A = A.to(dtype=ab_dtype)
    B = B.to(dtype=ab_dtype)
    # Error feedback: quantize the residual of the *rounded* factors (the
    # product the kernel actually computes), so their ab_dtype casting error
    # is absorbed by the FP8 stage instead of left uncompensated.
    Q_fp8, scale_inv = _quantize_to_fp8(W - A.float() @ B.float(), dtype=q_dtype)
    return A, B, Q_fp8, scale_inv


__all__ = ["decompose_weight"]
