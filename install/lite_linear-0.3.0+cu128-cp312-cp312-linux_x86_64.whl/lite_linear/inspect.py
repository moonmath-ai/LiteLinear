"""Read-only walks of a `.safetensors` file or sharded checkpoint directory.

This module is the "what's in this checkpoint?" side of the converter. It
opens shards lazily via `safe_open` and yields per-tensor metadata without
ever materializing the tensors themselves.
"""

import json
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

from safetensors import safe_open


@dataclass(frozen=True)
class WeightEntry:
    """One 2D `.weight` tensor seen on disk."""

    key: str
    shape: tuple[int, ...]
    num_params: int
    file: str
    """Basename of the source shard (same key can appear in multiple shards
    on a directory walk)."""


def _files_from_index(index_path: Path) -> list[Path]:
    """Resolve `weight_map` entries to absolute shard paths."""
    # JSONDecodeError propagates verbatim; missing shards surface later from
    # safe_open with a clearer message than we'd produce here.
    index = json.loads(index_path.read_text())
    weight_map = index.get("weight_map")
    if not isinstance(weight_map, dict) or not weight_map:
        raise ValueError(
            f"{index_path} doesn't look like a safetensors index (missing or empty `weight_map`)."
        )
    parent = index_path.parent
    return sorted({parent / shard for shard in weight_map.values()})


def iter_2d_weights(input_path: Path) -> Iterator[WeightEntry]:
    """Yield a `WeightEntry` for every 2D `.weight` tensor in the input.

    Skips 1D weights (norms) and non-`.weight` keys (`.bias`, scale factors).

    Dispatch by input shape:
      - `.safetensors` file → walk only that file.
      - `.safetensors.index.json` file → walk the shards listed in
        `weight_map` (any subdir paths are resolved relative to the
        index file's directory).
      - Directory → walk every `*.safetensors` file in the directory. Any
        `.safetensors.index.json` in the directory is ignored; if you want
        index semantics, point at the index file directly.

    Not supported:
      - `pytorch_model.bin` / `pytorch_model.bin.index.json` (pickle format).
        Convert via `huggingface_hub` / `safetensors-convert.hf.space` first.
      - Diffusers' multi-component layout (top-level `model_index.json` +
        `unet/`, `text_encoder/`, ...). Point at the specific component
        subfolder instead.
      - GGUF (llama.cpp), a different ecosystem entirely.
    """
    if input_path.is_file():
        if input_path.name.endswith(".safetensors.index.json"):
            files = _files_from_index(input_path)
        elif input_path.suffix.lower() == ".safetensors":
            files = [input_path]
        else:
            raise ValueError(
                f"Input must be a `.safetensors` file, a "
                f"`.safetensors.index.json` index, or a directory; got "
                f"{input_path.name}. PyTorch pickle checkpoints (.pt / "
                f".bin / .pth) aren't supported — convert to safetensors first."
            )
    elif input_path.is_dir():
        files = sorted(input_path.glob("*.safetensors"))
        if not files:
            raise FileNotFoundError(f"No `.safetensors` files found in {input_path}.")
    else:
        raise FileNotFoundError(f"input not found: {input_path}")

    # Stick to `get_slice(...).get_shape()`; `get_tensor(...)` reads the body
    # and turns a multi-GB walk into minutes.
    for path in files:
        with safe_open(str(path), framework="pt", device="cpu") as f:
            # safe_open exposes .keys() but isn't iterable as a dict.
            for key in f.keys():  # noqa: SIM118
                if not key.endswith(".weight"):
                    continue
                shape = tuple(f.get_slice(key).get_shape())
                if len(shape) != 2:
                    continue
                yield WeightEntry(
                    key=key,
                    shape=shape,
                    num_params=shape[0] * shape[1],
                    file=path.name,
                )


__all__ = ["WeightEntry", "iter_2d_weights"]
